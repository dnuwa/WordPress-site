<?php 
     add_theme_support('post-thumbnails'); 
     require_once('lib/enqueue-assets.php');
     // require_once('lib/metaboxes.php');
?>