<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <?php wp_head(); ?>
</head>
<body class="container">
    
    <div class="card-container">
      <?php if(have_posts()) { ?>
        <?php while(have_posts()) { ?>
          <?php the_post(); ?>
          <div class="card">
            <!-- <div class="card-header">-15%</div> -->
            <div class="card-header">
              -
              <?php echo intval(esc_attr(get_post_meta(get_the_ID(), '__twenetytwentyonejan_post_discount', true)))?>
              %
            </div>
            <?php if ( has_post_thumbnail() ) { ?>
            <div class="img-wrapper">
              
                <?php the_post_thumbnail(); ?>
            </div>
            <?php } else {?>
                <div class="img-wrapper">                
                  <img src="<?php echo get_template_directory_uri() . '/dist/assets/images/placeholder.jpg'; ?>" />
                </div>                
              <?php } ?>

            <!-- modal button -->
            <button class="card-text" data-toggle="modal" data-target="#postModal-<? the_ID(); ?>"><?php the_title_attribute(); ?>
              <div class="post-content"><?php the_excerpt() ?></div>
            </button>

            <div class="modal fade" id="postModal-<? the_ID(); ?>" tabindex="-1" role="dialog" aria-labelledby="postModalTitle" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"><?php the_title_attribute(); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <?php the_excerpt() ?>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>
            </div>
            

            <!-- modal -->
            <!-- <div class="modal">
              <div class="modal-content">
                  <div class="modal-header">
                    <span class="closeBtn">&times;</span>
                    <h2 id="title"><?php the_title_attribute(); ?></h2>
                  </div>
                  <div class="modal-body">
                    <P id="inner-title"> <?php the_title_attribute(); ?></P>
                    <br />
                    <p id="post-text"></p>
                  </div>
                  <div class="modal-footer">
                    <h3><?php the_title_attribute(); ?></h3>
                  </div>
              </div>
            </div> -->

            <div class="card-footer">
              <div class="cost">LKR <?php echo intval(esc_attr(get_post_meta(get_the_ID(),
               '__twenetytwentyonejan_post_price', true))) - (intval(esc_attr(get_post_meta(get_the_ID(), 
               '__twenetytwentyonejan_post_price', true))) * (intval(esc_attr(get_post_meta(get_the_ID(), 
               '__twenetytwentyonejan_post_discount', true)))/100))?></div>
               
              <div class="discounted">LKR <?php echo intval(esc_attr(get_post_meta(get_the_ID(), 
              '__twenetytwentyonejan_post_price', true)))?></div>
              </div>
          </div>
          <?php } ?>
          <?php } else { ?>
            <div>Sorry, no products matched your criteria. </p>
          <?php } ?>
      </div>
</body>
  <?php wp_footer(); ?>
</html>