<?php

function twentytwentyonejan_add_meta_box(){
    add_meta_box('twentytwentyonejan_post_meta_box', 'Discount', 'twentytwentyonejan_post_metabox_html', 'post', 'normal', 'default');
}

add_action('add_meta_boxes', 'twentytwentyonejan_add_meta_box');

function twentytwentyonejan_post_metabox_html($post){
    $post_discount = get_post_meta($post->ID, '_twentytwentyonejan_post_discount', true);
    $post_price = get_post_meta($post->ID, '_twentytwentyonejan_post_price', true);
    wp_nonce_field('twentytwentyonejan_update_post_metabox', 'twentytwentyonejan_update_post_once ');

    
    // wp_nonce_field('twentytwentyonejan_update_post_metabox', 'twentytwentyonejan_update_post_once ');

    ?>
        <p>
            <label for=""><?php esc_html_e('Post Discount', 'twentytwentyonejan'); ?></label>
            <br />
            <input type="text" name="twentytwentyonejan_post_discount_field" 
            id="twentytwentyonejan_post_discount_field" 
            value="<?php echo esc_attr($post_discount);?>"/>
        </p>
        <p>
            <label for=""><?php esc_html_e('Price', 'twentytwentyonejan'); ?></label>
            <br />
            <input type="text" name="twentytwentyonejan_post_price_field" 
            id="twentytwentyonejan_post_price_field" 
            value="<?php echo esc_attr($post_price);?>"/>
        </p>
    <?php
}

function twentytwentyonejan_save_post_metabox($post_id, $post ){
    // $edit_cap = get_post_type_object($post->post_type)->cap->edit_post;
    // if(current_user_can($edit_cap, $post_id)){
    //     return;
    // }

    // if(!isset( $_POST['twentytwentyonejan_update_post_once']) || !wp_verify_nonce($_POST
    // ['twentytwentyonejan_update_post_once'],'twentytwentyonejan_update_post_metabox')){
    //     return;
    // }

    if(array_key_exists('twentytwentyonejan_post_discount_field', $_POST)){
        update_post_meta($post_id, '_twentytwentyonejan_post_discount', 
        sanitize_text_field($_POST['twentytwentyonejan_post_discount_field']));
    }

    if(array_key_exists('twentytwentyonejan_post_price_field', $_POST)){
        update_post_meta($post_id, '_twentytwentyonejan_post_price', 
        sanitize_text_field($_POST['twentytwentyonejan_post_price_field']));
    }
}

add_action('save_post', 'twentytwentyonejan_save_post_metabox', 10, 2);