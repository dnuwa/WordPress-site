<?php

    function twentytwentyonejan_assets(){
        
        wp_enqueue_style( 'twentytwentyonejan-stylesheet', get_template_directory_uri() .  
        '/dist/assets/css/bundle.css', array(), 'all');

        wp_enqueue_script('twentytwentyonejan-scripts', get_template_directory_uri() . 
        '/dist/assets/js/bundle.js', array('jquery'), '', true);

        wp_enqueue_script( 'Bootstrap', get_template_directory_uri() . 
        '/dist/assets/bootstrap/js/bootstrap.min.js', array(), '4.5.3', true );

        wp_enqueue_style( 'Bootstrap_css', get_template_directory_uri() .  
        '/dist/assets/bootstrap/css/bootstrap.min.css', array(), 'all');
    }

add_action('wp_enqueue_scripts', 'twentytwentyonejan_assets');
